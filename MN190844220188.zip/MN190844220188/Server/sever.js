var express = require("express");
var config = require("new");
var mysql= require("mysql");
var port = parseInt(config.get("port"));
var app =  express();

var con =  mysql.createConnection({
    host: config.get("host"),
    database:config.get("database"),
    user : config.get("user"),
    password:config.get("password")
});
con.connect();
app.use(express.json());

app.get("/",(req, res)=>{
    var queryTxt = "select * from CricStatTB";
    
    connection.query(queryTxt,(err, resu)=>{
        if(err==null)
            {
                res.send(JSON.stringify(resu));
            }
            else{
                res.send(JSON.stringify(err));
            }
    });
});
app.get("/:Id",(req,res)=>{
    var queryTxt = `select * from  where id = ${request.params.Id}`;
    connection.query(queryTxt,(err, resu)=>{
        if(err==null)
            {
                res.send(JSON.stringify(resu));
            }
            else{
                res.send(JSON.stringify(err));
            }
    });
});
app.post("/" ,(req,res)=>{
    var queryTxt = `insert into CricStatTB values(${req.params.Id},${req.params.Country},${req.params.Year},${req.params.NoofTeam},${req.params.Venue},`;
    connection.query(queryText,(err, resu)=>{
        if(err==null)
            {
                res.send(JSON.stringify(resu));
            }
            else{
                res.send(JSON.stringify(err));
            }
    });
});

app.delete("/:V",(req,res)=>{
var queryText = `delete from  where Venue = ${req.params.V}`;
    connection.query(queryTxt,(err, resu)=>{
        if(err==null)
            {
                res.send(JSON.stringify(resu));
            }
            else{
                res.send(JSON.stringify(err));
            }
    });
});


app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});


app.listen(port, ()=>{
    console.log("Server Started on 3434..");
});




