import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {

    constructor(public http:HttpClient) { }
    Select()
    {
      return this.http.get("http://localhost:3434/list");
    }
    
    Delete(V)
    {
      return this.http.delete("http://localhost:3434/list/"+V);
    }
   
    Insert(entry)
    {
      return this.http.post("http://localhost:3434/list" ,entry);
    }
  }
