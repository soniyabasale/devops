import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  entries:any;
    constructor(private Service : ServiceService,private route:Router) { }
  
    ngOnInit() {
  
      let obres=this.Service.Select();
      obres.subscribe((res)=>{ 
        this.entries= res;
        console.log(res)
  
      })
      
    }
  }
