import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-insert',
  templateUrl: './insert.component.html',
  styleUrls: ['./insert.component.css']
})
export class InsertComponent implements OnInit {

    entry={"id":"","Country":"","Year":"","No":"","Ven":""};
    constructor(private route:ActivatedRoute,private router:Router,private service:ServiceService) { }
    message="";
    ngOnInit() {
    }
  
    Insert()
    {
      {
        console.log(this.entry);
        let obsres=this.service.Insert(this.entry);
        obsres.subscribe((res:any)=>{
    
          {
            this.message="entry added!";
            this.router.navigate(["home"])
          }
        console.log(res);
        
        })
      }
  
    }
   
  }