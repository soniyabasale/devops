import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {

  constructor(private route:ActivatedRoute,private router:Router,private service:ServiceService) { }

  ngOnInit() {
    this.route.paramMap.subscribe((res)=>{
      
      let V=res.get("Ven");
      console.log(V);
      let obsres=this.service.Delete(V);
      obsres.subscribe((records)=>{
        console.log(records);
        this.router.navigate(["home"])
      });

    });
  }

}